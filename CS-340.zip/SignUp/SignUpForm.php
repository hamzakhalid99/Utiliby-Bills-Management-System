<?php 
    include "../DB_Connection/database_connection.php";

    if (isset($_POST["submitted_form"]))
    {
        if ((!empty($_POST["user_email"])) && (!empty($_POST["user_fullname"])) && (!empty($_POST["user_cnic"])) &&(!empty($_POST["user_home"])) && (!empty($_POST["user_username"])) && (!empty($_POST["user_contact"])) && (!empty($_POST["user_password"])) && (!empty($_POST["user_role"])))
        {
            $obtained_fullname = $_POST["user_fullname"];
            $obtained_email = $_POST["user_email"];
            $obtained_cnic = $_POST["user_cnic"];
            $obtained_address = $_POST["user_home"];
            $obtained_username = $_POST["user_username"];
            $obtained_contact = $_POST["user_contact"]; 
            $obtained_password = $_POST["user_password"];
            $obtained_role = $_POST["user_role"];

            $write_query = "INSERT INTO User(name, cnic, contact_number, email_id, address, username, password, role)";
            $write_query .= "VALUES('$obtained_fullname', '$obtained_cnic', '$obtained_contact', '$obtained_email', '$obtained_address', '$obtained_username', '$obtained_password', '$obtained_role')";
            $result = mysqli_query($connect, $write_query);
        
            if (!$result)
                echo mysqli_error($connect);
            else 
                header("Location: ../Index.html");
        }
        else 
        {
            echo("<h2 style = 'color: red'> AT LEAST ONE OF THE FORM FIELDS IS EMPTY. GO BACK AND FILL THEM ALL TO AVIOD ERRORS</h2>");
        }
    }
?>
